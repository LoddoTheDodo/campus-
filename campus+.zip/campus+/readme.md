# Kickstarter

Download projektet som ZIP-fil


## Kør "setup" kommandoen her under hvis det er første gang du åbner projektet
```sh
npm run setup
```

Setup kommandoen kører "npm install" og "npm run sass" på én gang.

I package.json filen kan du under "scripts" finde sass kommandoen alene.
Du kan også kører den herfra:

## Hvis det IKKE er første gang du åbner projektet
```sh
npm run sass
```
